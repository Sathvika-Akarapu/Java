package Day_3;

public class StringMethods {
    // public static void main(String[] args) {
    	 String s1="prince";//to get tostring click on the current cursor then right click then goto source then generate tostring then it automatically generate the override
    	 String s2="queen";
		@Override
		public String toString() {
			return "StringMethods [s1=" + s1 + ", s2=" + s2 + "]";
		}
    	 
     }

//}
