package Day_3;
abstract class Test9{
	abstract void display1();
	static void display2();
	
	
}

public class Demo6 {

}
