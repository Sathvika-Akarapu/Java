package Day_3;

public class StringBuffer1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="listen";
		String s2="silent";
		StringBuffer sb1=new StringBuffer(s1);
		StringBuffer sb2=new StringBuffer(s2);
	    System.out.println(sb1.append(sb2));
		

	}

}
